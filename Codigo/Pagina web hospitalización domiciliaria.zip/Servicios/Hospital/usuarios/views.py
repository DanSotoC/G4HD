from django.shortcuts import render
from django.views.generic import TemplateView
from .models  import usuario
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy

""" Index"""

class HomePageView(TemplateView):
    def get (self, request, **kwargs):
       return render(request,'Index.html', context=None)






""" Pacientes"""

class HomePacientesView(LoginRequiredMixin,TemplateView):
    def get(self, request, **kwargs):

        
         return render(request, 'pacientes.html', {'pacientes':usuario.usuarios.filter(id_usuario__contains='P')})


class DetallePacienteView(LoginRequiredMixin,TemplateView):
    def get (self , request, **kwargs):
        id_usuario=kwargs[ "id_usuario"]
        return render(request,'paciente.html' , {'usuario':usuario.usuarios.get(id_usuario=id_usuario)})


class pacienteCreate(CreateView):
    model=usuario
    template_name='./paciente_form.html'
    fields='__all__'



class pacienteUpdate(UpdateView):
    model=usuario
    template_name='./paciente_form.html'
    fields=['id_usuario','nombre','apellido','edad','rut','comuna','direccion','num_direccion','telefono_cel','telefono_casa', 'tipo']


class pacienteDelete(DeleteView):
    model=usuario
    template_name='./paciente_confirm_delete.html'
    success_url= reverse_lazy('usuarios')








""" Tutores """

class HomeTutoresView(LoginRequiredMixin,TemplateView):
    def get(self, request, **kwargs):

        
         return render(request, 'tutores.html', {'tutores':usuario.usuarios.filter(id_usuario__contains='T')})


class DetalleTutorView(LoginRequiredMixin,TemplateView):
    def get (self , request, **kwargs):
        id_usuario=kwargs[ "id_usuario"]
        return render(request,'tutor.html' , {'usuario':usuario.usuarios.get(id_usuario=id_usuario)})


class tutorCreate(CreateView):
    model=usuario
    template_name='./tutor_form.html'
    fields='__all__'



class tutorUpdate(UpdateView):
    model=usuario
    template_name='./tutor_form.html'
    fields=['id_usuario','nombre','apellido','edad','rut','comuna','direccion','num_direccion','telefono_cel','telefono_casa', 'tipo']


class tutorDelete(DeleteView):
    model=usuario
    template_name='./tutor_confirm_delete.html'
    success_url= reverse_lazy('usuarios')
        









"""  Personal  """
class HomeUsuariosView(LoginRequiredMixin,TemplateView):
    def get(self, request, **kwargs):
         return render(request, 'usuarios.html', {'usuarios':usuario.usuarios.filter(id_usuario__contains='E')})


class DetalleUsuarioView(LoginRequiredMixin,TemplateView):
    def get (self , request, **kwargs):
        id_usuario=kwargs[ "id_usuario"]
        return render(request,'usuario.html' , {'usuario':usuario.usuarios.get(id_usuario=id_usuario)})

class usuarioCreate(CreateView):
    model=usuario
    template_name='./usuario_form.html'
    fields='__all__'


class usuarioUpdate(UpdateView):
    model=usuario
    template_name='./usuario_form.html'
    fields=['id_usuario','nombre','apellido','edad','rut','comuna','direccion','num_direccion','telefono_cel','telefono_casa', 'tipo']


class usuarioDelete(DeleteView):
    model=usuario
    template_name='./usuario_confirm_delete.html'
    success_url= reverse_lazy('usuarios')





# Create your views here.

from django.db import models


class  usuario(models.Model):
    id_usuario=models.CharField(max_length=6)
    nombre=models.CharField(max_length=60)
    apellido=models.CharField(max_length=60)
    edad=models.IntegerField()
    rut=models.CharField(max_length=15)
    comuna=models.CharField(max_length=15)
    direccion=models.CharField(max_length=60)
    num_direccion=models.CharField(max_length=5, null=True )
    telefono_cel=models.IntegerField(null=True)
    telefono_casa=models.IntegerField(null=True)
    tipo=models.CharField(max_length=20)
    
    usuarios=models.Manager()


    def __str__(self):
        return "{}".format(self.nombre)


# Create your models here.

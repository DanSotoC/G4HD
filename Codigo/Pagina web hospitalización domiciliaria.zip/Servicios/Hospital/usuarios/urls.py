from django.conf.urls import url, re_path
from django.urls import path, include
from usuarios import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    url(r'^$',views.HomePageView.as_view(), name="Index"),
    url(r'usuarios/',views.HomeUsuariosView.as_view(), name="usuarios"),
    url(r'^usuario/create/$',views.usuarioCreate.as_view(success_url='/usuarios/'),name='usuario_create'),
    url(r'^usuario/(?P<pk>\d+)/update/$',views.usuarioUpdate.as_view(success_url='/usuarios/'),name='usuario_update'),
    url(r'^usuario/(?P<pk>\d+)/delete/$',views.usuarioDelete.as_view(success_url='/usuarios/'),name='usuario_delete'),
   
    
    url(r'pacientes/',views.HomePacientesView.as_view(), name="pacientes"),
    url(r'^paciente/create/$',views.pacienteCreate.as_view(success_url='/pacientes/'),name='paciente_create'),
    url(r'^paciente/(?P<pk>\d+)/update/$',views.pacienteUpdate.as_view(success_url='/pacientes/'),name='paciente_update'),
    url(r'^paciente/(?P<pk>\d+)/delete/$',views.pacienteDelete.as_view(success_url='/pacientes/'),name='pacientes_delete'),
   
    url(r'tutores/',views.HomeTutoresView.as_view(), name="tutores"),
    url(r'^tutor/create/$',views.tutorCreate.as_view(success_url='/tutores/'),name='tutor_create'),
    url(r'^tutor/(?P<pk>\d+)/update/$',views.tutorUpdate.as_view(success_url='/tutores/'),name='tutor_update'),
    url(r'^tutor/(?P<pk>\d+)/delete/$',views.tutorDelete.as_view(success_url='/tutores/'),name='tutor_delete'),
    re_path(r'tutor/(?P<id_usuario>T[0-9]{3})/$',views.DetalleTutorView.as_view(), name="detalle_tutor"),
    re_path(r'tutor/(?P<id_usuario>E[0-9]{3})/$',views.DetalleTutorView.as_view(), name="detalle_tutor"),
    re_path(r'tutor/(?P<id_usuario>P[0-9]{3})/$',views.DetalleTutorView.as_view(), name="detalle_tutor"),
    re_path(r'usuario/(?P<id_usuario>E[0-9]{3})/$',views.DetalleUsuarioView.as_view(), name="detalle_usuario"),
    re_path(r'usuario/(?P<id_usuario>P[0-9]{3})/$',views.DetalleUsuarioView.as_view(), name="detalle_usuario"),
    re_path(r'usuario/(?P<id_usuario>T[0-9]{3})/$',views.DetalleUsuarioView.as_view(), name="detalle_usuario"),
    re_path(r'paciente/(?P<id_usuario>P[0-9]{3})/$',views.DetallePacienteView.as_view(), name="detalle_paciente"),
    re_path(r'paciente/(?P<id_usuario>E[0-9]{3})/$',views.DetallePacienteView.as_view(), name="detalle_paciente"),
    re_path(r'paciente/(?P<id_usuario>T[0-9]{3})/$',views.DetallePacienteView.as_view(), name="detalle_paciente"),
    path('accounts/', include('accounts.urls')),
    path('accounts/', include('django.contrib.auth.urls'))
   

]   

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT) 